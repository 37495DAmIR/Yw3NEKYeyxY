"""
Developer: Harshal(Error404)
Website: gcscouncil.com
"""
from setuptools import setup, find_packages


setup(
    name='gcsdoc',
    version="2.1",
    packages=find_packages(),
    author="Harshal(Error404)",
    install_requires=["httpx"],
    description="Fetch information about Google document.",
    include_package_data=True,
    url='https://github.com/Malfrats/xeuledoc',
    entry_points = {'console_scripts': ['xeuledoc = xeuledoc.core:main']},
    classifiers=[
        "Programming Language :: Python",
        "License :: OSI Approved :: GNU General Public License v3 (GPLv3)",
    ],
)
